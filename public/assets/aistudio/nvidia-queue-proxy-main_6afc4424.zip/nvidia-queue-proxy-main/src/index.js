
import { DurableObject } from "cloudflare:workers";

const NVIDIA_API = "https://integrate.api.nvidia.com";
const WINDOW_MS = 60_000;
const DEFAULT_RPM = 40;
const DEFAULT_COOLDOWN_MS = 1_670;
const MAX_429_RETRIES = 5;
const MAX_BACKOFF_MS = 30_000;

const sleep = (ms) =>
  new Promise((resolve) => setTimeout(resolve, ms));

function retryAfterMs(response) {
  const value = response.headers.get("Retry-After");
  if (!value) return 0;

  const seconds = Number(value);
  if (Number.isFinite(seconds) && seconds >= 0) {
    return seconds * 1000;
  }

  const date = Date.parse(value);
  return Number.isFinite(date)
    ? Math.max(0, date - Date.now())
    : 0;
}

function safeResponseHeaders(headers) {
  const result = new Headers(headers);
  for (const name of [
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade",
    "content-length",
  ]) {
    result.delete(name);
  }
  return result;
}

export class RateGate extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.queue = Promise.resolve();
  }

  async fetch(request) {
    const url = new URL(request.url);

    if (request.method !== "POST" || !url.pathname.startsWith("/v1/")) {
      return new Response("Not found", { status: 404 });
    }

    // Reserve the queue position synchronously, before yielding.
    const previous = this.queue;
    let releaseSlot;
    const slot = new Promise((resolve) => {
      releaseSlot = resolve;
    });
    this.queue = previous.then(() => slot);

    await previous;

    let released = false;
    const release = () => {
      if (released) return;
      released = true;
      releaseSlot();
    };

    try {
      const rpm = Math.max(
        1,
        Math.min(1000, Number(this.env.RPM) || DEFAULT_RPM)
      );
      const cooldownMs = Math.max(
        0,
        Math.min(
          60_000,
          Number(this.env.COOLDOWN_MS) || DEFAULT_COOLDOWN_MS
        )
      );

      const body = await request.arrayBuffer();
      const state =
        (await this.ctx.storage.get("rate-state")) || {
          starts: [],
          lastSendAt: 0,
          lastCompletionAt: 0,
        };

      const waitForSlot = async () => {
        while (true) {
          const now = Date.now();
          state.starts = state.starts.filter(
            (time) => now - time < WINDOW_MS
          );

          let wait = 0;

          if (state.starts.length >= rpm) {
            wait = Math.max(
              wait,
              state.starts[0] + WINDOW_MS - now
            );
          }

          if (state.lastCompletionAt) {
            wait = Math.max(
              wait,
              state.lastCompletionAt + cooldownMs - now
            );
          }

          if (state.lastSendAt) {
            wait = Math.max(
              wait,
              state.lastSendAt + cooldownMs - now
            );
          }

          if (wait <= 0) return;

          await sleep(wait);
        }
      };

      let upstreamResponse;

      for (let retry = 0; ; retry++) {
        await waitForSlot();

        state.lastSendAt = Date.now();
        await this.ctx.storage.put("rate-state", state);

        const upstreamUrl = new URL(
          url.pathname + url.search,
          NVIDIA_API
        );

        const headers = new Headers(request.headers);
        headers.set(
          "Authorization",
          `Bearer ${this.env.NVIDIA_API_KEY}`
        );
        headers.delete("host");
        headers.delete("x-proxy-key");
        headers.delete("content-length");

        try {
          upstreamResponse = await fetch(upstreamUrl, {
            method: "POST",
            headers,
            body,
            redirect: "manual",
          });
        } catch (error) {
          state.lastCompletionAt = Date.now();
          await this.ctx.storage.put("rate-state", state);
          throw error;
        }

        if (upstreamResponse.status !== 429) break;

        const retryDelay = Math.min(
          MAX_BACKOFF_MS,
          1000 * 2 ** retry,
          Math.max(1000, retryAfterMs(upstreamResponse))
        );

        // Preserve the final 429 response if retries are exhausted.
        const retryBody = await upstreamResponse.arrayBuffer();
        const retryHeaders = safeResponseHeaders(
          upstreamResponse.headers
        );

        state.lastCompletionAt = Date.now();
        await this.ctx.storage.put("rate-state", state);

        if (retry >= MAX_429_RETRIES) {
          release();
          return new Response(retryBody, {
            status: 429,
            headers: retryHeaders,
          });
        }

        await sleep(retryDelay);
      }

      // Count only requests that were not rejected with HTTP 429.
      state.starts = state.starts.filter(
        (time) => Date.now() - time < WINDOW_MS
      );
      state.starts.push(Date.now());
      await this.ctx.storage.put("rate-state", state);

      const responseHeaders = safeResponseHeaders(
        upstreamResponse.headers
      );

      if (!upstreamResponse.body) {
        state.lastCompletionAt = Date.now();
        await this.ctx.storage.put("rate-state", state);
        release();

        return new Response(null, {
          status: upstreamResponse.status,
          statusText: upstreamResponse.statusText,
          headers: responseHeaders,
        });
      }

      // Keep the queue occupied until the response stream ends
      // or the client cancels it.
      const reader = upstreamResponse.body.getReader();

      const finish = async () => {
        try {
          state.lastCompletionAt = Date.now();
          await this.ctx.storage.put("rate-state", state);
        } finally {
          release();
        }
      };

      const stream = new ReadableStream({
        async pull(controller) {
          try {
            const result = await reader.read();

            if (result.done) {
              controller.close();
              await finish();
            } else {
              controller.enqueue(result.value);
            }
          } catch (error) {
            controller.error(error);
            await finish();
          }
        },

        async cancel(reason) {
          try {
            await reader.cancel(reason);
          } finally {
            await finish();
          }
        },
      });

      return new Response(stream, {
        status: upstreamResponse.status,
        statusText: upstreamResponse.statusText,
        headers: responseHeaders,
      });
    } catch (error) {
      release();
      return Response.json(
        { error: "Proxy upstream request failed" },
        { status: 502 }
      );
    }
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/health" && request.method === "GET") {
      return Response.json({ ok: true });
    }

    if (!env.PROXY_KEY || !env.NVIDIA_API_KEY) {
      return new Response("Server configuration error", {
        status: 500,
      });
    }

    // Accept the proxy key in either standard Bearer auth or
    // the optional x-proxy-key header.
    const authorization = request.headers.get("Authorization") || "";
    const suppliedKey = authorization.startsWith("Bearer ")
      ? authorization.slice(7)
      : request.headers.get("x-proxy-key") || "";

    if (suppliedKey !== env.PROXY_KEY) {
      return new Response("Unauthorized", { status: 401 });
    }

    if (request.method !== "POST" || !url.pathname.startsWith("/v1/")) {
      return new Response("Not found", { status: 404 });
    }

    const id = env.RATE_GATE.idFromName("nvidia-global-queue");
    return env.RATE_GATE.get(id).fetch(request);
  },
};
